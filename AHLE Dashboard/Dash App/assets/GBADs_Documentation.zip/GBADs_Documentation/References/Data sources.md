# Data sources

Short name | Long name | URL
---|---|---
FAO | Food and Agriculture Organization of the United Nations | https://www.fao.org/faostat/en/#data/
Eurostat | European Commission | https://ec.europa.eu/eurostat/databrowser/