# Understanding the charts

There are two charts for each species: the production chart and the costs chart. See the following pages for information about each.