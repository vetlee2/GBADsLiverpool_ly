# Year

The data behind the tool deteremines the amount of history we have 
and what we can display for each species and location.

The current data allows views from 2011 to 2020 for each species, 
and data availability may vary from country to country.