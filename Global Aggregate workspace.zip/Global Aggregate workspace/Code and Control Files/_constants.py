lbs_per_kg = 2.204623
