# Downloading results

<h3>Saving chart images</h3>

Click on the camera icon (![Screenshot icon](../Images/camera_icon.png)) at the top right corner of each chart to download the chart with the current settings as a `.png` file.

<h3>Saving background data</h3>

Click on the 'export' button (![Export icon](../Images/export_icon.png)) under the title of each table to download the data with the current settings as a `.csv` file.
