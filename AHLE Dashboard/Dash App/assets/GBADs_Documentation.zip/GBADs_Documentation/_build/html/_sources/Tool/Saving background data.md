# Saving background data

Each data table has a built-in option for saving as a `.csv` file.

Under the title of each table, there is an 'export' button that looks 
like this: ![Export icon](../Images/export_icon.png)

Click on that button and it will automatically save and download 
the `.csv` file for the data table with the filters selected on the page.