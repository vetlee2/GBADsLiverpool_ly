# Reading the charts
<p>
Each species tab shows two charts: the production chart and the cost chart. The production chart shows the burden of disease in terms of lost production potential, while the cost chart shows the burden of disease in terms of increased costs.
</p>
<p>
See the following pages for information about each chart.
</p>