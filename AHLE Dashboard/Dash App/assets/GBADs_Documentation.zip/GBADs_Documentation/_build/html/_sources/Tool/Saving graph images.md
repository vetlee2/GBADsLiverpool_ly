# Saving graph images

Each graph has a built-in option for taking screenshots and saving 
them as a `.png` file.

At the top right corner of the graph, there is a camera icon 
that looks like this: ![Screenshot icon](../Images/camera_icon.png)

Click on that icon and it will automatically save and download 
the `.png` screenshot of the graph.

