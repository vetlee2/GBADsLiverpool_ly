# Costs chart

The costs chart shows side-by-side bars comparing the actual costs of production and the ideal costs if there were no disease burden.

```{figure} ../Images/poultry_costs_1.png
---
#height: 700px
name: poultry_costs_1
---
Example costs chart
```
