# GBADs Liverpool

A space for code made by Liverpool modellers in the Global Burden of Animal Diseases (GBADs). For each of your models please follow the best practices set by GBADs Informatics, as articulated in the [Data Governance Handbook](http://www.gbadske.org/Documentation/DataGovernanceHandbook/codeBestPractices.html). 

For larger projects that may require multiple files, a project-specific repository may be required. Please contact GBADs Informatics so we can link to a new repository. 
