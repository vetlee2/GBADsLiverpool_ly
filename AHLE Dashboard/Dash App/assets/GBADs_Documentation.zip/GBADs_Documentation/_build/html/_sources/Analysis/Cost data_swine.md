# Cost data

Actual costs for swine come from the interPIG organization. These yearly reports can be accessed from [the AHDB website](https://ahdb.org.uk/cost-of-production-in-selected-countries).
