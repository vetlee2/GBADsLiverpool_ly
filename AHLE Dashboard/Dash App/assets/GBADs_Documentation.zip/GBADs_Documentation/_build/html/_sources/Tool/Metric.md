# Metric

The tool has different options for the 'metric' dropdown. This 
allows the user to view the data and the graphs with a different 
scaling factor.

Currently there are 3 choices for metric:

1. Tonnes
2. US Dollars
3. Percent of GDP