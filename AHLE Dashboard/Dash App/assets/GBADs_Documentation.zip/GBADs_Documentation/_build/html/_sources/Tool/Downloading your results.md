# Downloading your results

<h3>Saving chart images</h3>
At the top right corner of each chart, there is a camera icon that looks like this: ![Screenshot icon](camera_icon.png)

Click on that icon to download the chart with the current settings as a `.png` file.

<h3>Saving background data</h3>
Under the title of each table, there is an 'export' button that looks like this: ![Export icon](export_icon.png)

Click on that button to download the data with the current settings as a `.csv` file.
