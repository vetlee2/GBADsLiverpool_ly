# Reading the data tables
<p>
Two data tables appear below the charts: the main table and the breed standard table. See the following pages for information about each.
</p>