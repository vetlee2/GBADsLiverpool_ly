# Calculating head placed

For swine, head placed is calculated as head weaned adjusted for net imports.

Because data on head weaned is not available for most countries, we calculate this as (Breeding sows) x (Pigs weaned per sow per year).
