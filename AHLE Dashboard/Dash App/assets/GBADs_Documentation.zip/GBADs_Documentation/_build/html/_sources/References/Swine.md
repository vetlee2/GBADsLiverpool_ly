# Swine

|Short name | Organization | Table | URL | Date accessed |
|---|---|---|---|---|
| Eurostat | European Commission | Eurostat pig population data | https://ec.europa.eu/eurostat/databrowser/view/APRO_MT_LSPIG__custom_2163011/ | Feb. 1, 2022 |
| InterPIG | InterPIG | Pig meat production annual reports | https://ahdb.org.uk/cost-of-production-in-selected-countries | May 2, 2022 |
| Pig333 | Pig333 | Pig production data | https://www.pig333.com/pig-production-data/ | Apr. 4, 2022 |
| | | Pig prices | https://www.pig333.com/markets_and_prices/ | Apr. 4, 2022 |
| UK FSA | United Kingdom Food Standards Agency | Pig conditions data | https://data.food.gov.uk/catalog/datasets/f99254ab-9cf5-4a04-ac34-fbb166db5d9a | Mar.2, 2022 |
| PIC | Pig Improvement Company | Wean-To-Finish Guidelines | https://www.pic.com/resources/wean-to-finish-manual-english/ | Apr.4, 2022