# Breed standards

Breed standards are less specific for swine than for poultry because there are many different swine breeds and hybrids. Any reference to swine breed standards in this dashboard uses data from the [Pig Improvement Company](https://www.pic.com/), specifically their wean-to-finish performance guidelines (https://www.pic.com/resources/wean-to-finish-manual-english/).