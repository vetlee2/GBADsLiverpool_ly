# Species

The current species covered within the tool are poultry and swine. 
We hope to add beef and salmon in the near future. 

The Ethiopia case study includes small ruminants currently, with 
the hopes to include more in the future.