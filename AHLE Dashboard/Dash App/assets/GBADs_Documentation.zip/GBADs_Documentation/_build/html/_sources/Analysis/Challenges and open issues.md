# Challenges and open issues

<h3>Data availability</h3>

<h3>Data quality</h3>
